1:"$Sreact.fragment"
2:I[64992,["/_next/static/chunks/09ft~1yunuh.i.js"],"default"]
3:I[39363,["/_next/static/chunks/09ft~1yunuh.i.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"Szgp0bSRAGg1twU6lLj2t"}

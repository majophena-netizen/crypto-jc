module.exports=[78346,(e,o,d)=>{}];

//# sourceMappingURL=opus_frontend__next-internal_server_app_favicon_ico_route_actions_0w_3mu7.js.map
module.exports=[24230,(a,b,c)=>{}];

//# sourceMappingURL=opus_frontend__next-internal_server_app__global-error_page_actions_0z~hee7.js.map
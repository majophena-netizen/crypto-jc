module.exports=[1449,(a,b,c)=>{}];

//# sourceMappingURL=opus_frontend__next-internal_server_app__not-found_page_actions_06q3j7b.js.map
module.exports=[648,(a,b,c)=>{}];

//# sourceMappingURL=opus_frontend__next-internal_server_app_page_actions_0lmnr36.js.map
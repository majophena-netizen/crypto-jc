globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/Szgp0bSRAGg1twU6lLj2t/_buildManifest.js",
    "static/Szgp0bSRAGg1twU6lLj2t/_ssgManifest.js",
    "static/Szgp0bSRAGg1twU6lLj2t/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0wsa3_h~si7gy.js",
    "static/chunks/0vpfcrsqqibme.js",
    "static/chunks/0h7~jzxpsz4yj.js",
    "static/chunks/turbopack-050daasqet5o1.js"
  ]
};

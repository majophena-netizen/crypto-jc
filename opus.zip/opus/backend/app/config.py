"""Application configuration loaded from environment variables."""

from __future__ import annotations

from pydantic import AliasChoices, Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Runtime configuration for the trading backend.

    All secrets must come from the environment. Never hard-code credentials.
    """

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # --- Exchange ---
    binance_api_key: str = Field(default="", alias="BINANCE_API_KEY")
    binance_api_secret: str = Field(default="", alias="BINANCE_API_SECRET")
    binance_testnet_key: str = Field(
        default="",
        validation_alias=AliasChoices("BINANCE_TESTNET_KEY", "BINANCE_DEMO_KEY"),
    )
    binance_testnet_secret: str = Field(
        default="",
        validation_alias=AliasChoices("BINANCE_TESTNET_SECRET", "BINANCE_DEMO_SECRET"),
    )
    binance_testnet: bool = Field(
        default=True,
        validation_alias=AliasChoices("BINANCE_TESTNET", "BINANCE_API_TESTNET"),
    )

    @property
    def active_binance_key(self) -> str:
        if self.binance_testnet:
            return self.binance_testnet_key or self.binance_api_key
        return self.binance_api_key

    @property
    def active_binance_secret(self) -> str:
        if self.binance_testnet:
            return self.binance_testnet_secret or self.binance_api_secret
        return self.binance_api_secret

    market_data_exchange: str = Field(default="binance", alias="MARKET_DATA_EXCHANGE")

    # --- AI ---
    anthropic_api_key: str = Field(default="", alias="ANTHROPIC_API_KEY")
    anthropic_model: str = Field(default="claude-sonnet-4-5", alias="ANTHROPIC_MODEL")
    gemini_api_key: str = Field(
        default="",
        validation_alias=AliasChoices("GEMINI_API_KEY", "GEMINI_API"),
    )
    gemini_model: str = Field(default="gemini-2.5-flash-lite", alias="GEMINI_MODEL")
    gemini_fallback_model: str = Field(default="gemini-flash-latest", alias="GEMINI_FALLBACK_MODEL")
    ai_provider: str = Field(default="auto", alias="AI_PROVIDER")

    @property
    def active_ai_provider(self) -> str:
        choice = (self.ai_provider or "auto").lower()
        if choice == "gemini" and self.gemini_api_key:
            return "gemini"
        if choice == "anthropic" and self.anthropic_api_key:
            return "anthropic"
        if self.gemini_api_key:
            return "gemini"
        if self.anthropic_api_key:
            return "anthropic"
        return ""

    # --- Trading symbol / timeframe ---
    symbol: str = Field(default="BTC/USDT", alias="TRADING_SYMBOL")
    timeframe: str = Field(default="15m", alias="TRADING_TIMEFRAME")
    scan_symbols_csv: str = Field(
         #default="BTC/USDT,ETH/USDT,SOL/USDT,BNB/USDT,XRP/USDT,DOGE/USDT,ADA/USDT,AVAX/USDT",
        default="BTC/USDT,ETH/USDT,SOL/USDT",
        alias="SCAN_SYMBOLS",
    )

    @property
    def scan_symbols(self) -> list[str]:
        raw = self.scan_symbols_csv or self.symbol
        out: list[str] = []
        for piece in raw.split(","):
            s = piece.strip().upper()
            if s and s not in out:
                out.append(s)
        return out or [self.symbol]

    # --- Default mode on startup: "signals" | "paper" | "live" ---
    default_mode: str = Field(default="paper", alias="DEFAULT_MODE")

    # --- Paper trading ---
    paper_starting_usdt: float = Field(
        default=10_000.0,
        validation_alias=AliasChoices("PAPER_STARTING_USDT", "START_BALANCE"),
    )
    paper_fee_bps: float = Field(default=10.0, alias="PAPER_FEE_BPS")  # 0.10%

    # --- Live trading safety ---
    live_max_order_usdt: float = Field(default=50.0, alias="LIVE_MAX_ORDER_USDT")

    # --- Auto-trading ---
    auto_trade_enabled: bool = Field(default=True, alias="AUTO_TRADE_ENABLED")
    entry_position_usdt: float = Field(default=1000.0, alias="ENTRY_POSITION_USDT")
    take_profit_pct: float = Field(default=2.0, alias="TAKE_PROFIT_PCT")
    stop_loss_pct: float = Field(default=1.5, alias="STOP_LOSS_PCT")
    min_ai_confidence: float = Field(default=0.4, alias="MIN_AI_CONFIDENCE")
    auto_trade_cooldown_seconds: int = Field(default=120, alias="AUTO_TRADE_COOLDOWN_SECONDS")
    max_concurrent_positions: int = Field(default=3, alias="MAX_CONCURRENT_POSITIONS")

    # --- Trailing stop + timeout exits ---
    trailing_stop_pct: float = Field(default=1.0, alias="TRAILING_STOP_PCT")
    trailing_arm_pct: float = Field(default=0.5, alias="TRAILING_ARM_PCT")
    max_hold_hours: float = Field(default=12.0, alias="MAX_HOLD_HOURS")

    # --- Anti-churn: minimum hold time before ANY signal-based exit fires ---
    # TP and SL still trigger immediately (they protect capital).
    # All other exits (signal, reversal, weak, weak_tp) are blocked until
    # min_hold_minutes have elapsed since entry.
    # Default 30 min = 2 candles on 15m timeframe. Set to 0 to disable.
    min_hold_minutes: float = Field(default=30.0, alias="MIN_HOLD_MINUTES")

    # --- Signal reversal exits ---
    # Raised from 3 → 8: at scan_interval=300s this is 40 min of sustained
    # weakness before a forced exit. Avoids closing on single-candle noise.
    signal_weak_ticks: int = Field(default=8, alias="SIGNAL_WEAK_TICKS")

    # Tightened from -0.4 → -0.7: only exit on strong reversals confirmed by
    # both technicals and AI, not routine pullbacks within an uptrend.
    reversal_conviction_threshold: float = Field(
        default=-0.7, alias="REVERSAL_CONVICTION_THRESHOLD"
    )

    # Raised from 0.5% → 1.2%: must comfortably exceed round-trip fees (0.2%)
    # and represent a meaningful gain before locking in early.
    weak_take_profit_pct: float = Field(default=1.2, alias="WEAK_TAKE_PROFIT_PCT")

    # --- Strategy knobs ---
    rsi_period: int = Field(default=14, alias="RSI_PERIOD")
    rsi_oversold: float = Field(default=30.0, alias="RSI_OVERSOLD")
    rsi_overbought: float = Field(default=70.0, alias="RSI_OVERBOUGHT")
    macd_fast: int = Field(default=12, alias="MACD_FAST")
    macd_slow: int = Field(default=26, alias="MACD_SLOW")
    macd_signal: int = Field(default=9, alias="MACD_SIGNAL")
    ma_fast: int = Field(default=20, alias="MA_FAST")
    ma_slow: int = Field(default=50, alias="MA_SLOW")

    # --- Scheduler ---
    # Raised from 60s → 300s: one scan per 15m candle, not 15 scans per candle.
    # Eliminates signal noise from intra-candle price jitter.
    scan_interval_seconds: int = Field(default=300, alias="SCAN_INTERVAL_SECONDS")
    use_ai_confirmation: bool = Field(default=True, alias="USE_AI_CONFIRMATION")
    max_ai_signals: int = Field(default=1, alias="MAX_AI_SIGNALS")

    # --- Storage ---
    database_url: str = Field(
        default="sqlite+aiosqlite:///./trader.db", alias="DATABASE_URL"
    )

    # --- CORS (frontend origin) ---
    cors_origins: str = Field(default="*", alias="CORS_ORIGINS")


settings = Settings()

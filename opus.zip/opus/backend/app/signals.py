from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, asdict, field

from sqlalchemy.ext.asyncio import AsyncSession

from app import exchange, indicators
from app.trading.market_regime import detect_market_regime
from app.ai import AIVerdict, analyse
from app.config import settings
from app.db import Signal, Trade

logger = logging.getLogger(__name__)

# =====================================
# CACHE
# =====================================
_ai_cache = {}
CACHE_TTL = 300


def get_cached_ai(symbol):
    data = _ai_cache.get(symbol)
    if not data:
        return None
    if time.time() - data["time"] > CACHE_TTL:
        return None
    return data["value"]


def set_cached_ai(symbol, verdict):
    _ai_cache[symbol] = {
        "value": verdict,
        "time": time.time()
    }


# =====================================
# RESULT OBJECT
# =====================================
@dataclass
class SignalResult:
    symbol: str
    snapshot: indicators.IndicatorSnapshot
    final_action: str
    explanation: str
    regime: str = "UNKNOWN"
    verdict: AIVerdict = field(
        default_factory=lambda: AIVerdict(action="hold", confidence=0.0, rationale="no AI")
    )

    @property
    def conviction(self) -> float:
        tech = abs(self.snapshot.score)
        ai_sign = {"buy": 1.0, "sell": -1.0, "hold": 0.0}.get(self.verdict.action, 0.0)
        ai_w = ai_sign * max(0.0, min(1.0, self.verdict.confidence))
        return abs(0.5 * self.snapshot.score + 0.5 * ai_w)


# =====================================
# STRATEGY
# =====================================
def _decide(snap):
    score = snap.score

    if score > 0.6 and snap.rsi < 65 and snap.macd > snap.macd_signal and snap.ma_vote == 1:
        return "buy", "trend up + momentum + RSI healthy"

    if score < -0.6 and snap.rsi > 35 and snap.macd < snap.macd_signal and snap.ma_vote == -1:
        return "sell", "trend down + momentum + RSI weak"

    if snap.bb_vote == 1 and snap.rsi < 30:
        return "buy", "oversold bounce (Bollinger)"

    if snap.bb_vote == -1 and snap.rsi > 70:
        return "sell", "overbought rejection (Bollinger)"

    return "hold", "no clear edge"


def _should_call_ai(snap):
    return abs(snap.score) > 0.4 or snap.rsi < 30 or snap.rsi > 70 or snap.bb_vote != 0


def _explanation(snap, reason):
    return (
        f"RSI={snap.rsi:.1f}, "
        f"MACD={snap.macd:.4f}, "
        f"MA trend={snap.ma_vote}, "
        f"BB={snap.bb_vote}. "
        f"{reason}"
    )


# =====================================
# SNAPSHOT
# =====================================
async def _compute_snapshot(symbol: str):
    try:
        candles = await exchange.fetch_ohlcv(symbol=symbol)
        snap = indicators.compute(candles)
        return snap, candles
    except Exception as e:
        logger.warning("candles(%s) failed: %s", symbol, e)
        return None


# =====================================
# PERSIST (IA CONTROLLEE)
# =====================================
async def _persist(session, symbol, snap, candles=None, use_ai=True):
    action, reason = _decide(snap)
    explanation = _explanation(snap, reason)

    # Filtre régime de marché — bloquer BUY en RANGE/CHAOS
    regime = "UNKNOWN"
    if candles:
        try:
            import pandas as pd
            df = pd.DataFrame(
                [(c.ts, c.open, c.high, c.low, c.close, c.volume) for c in candles],
                columns=["ts", "open", "high", "low", "close", "volume"]
            )
            regime = detect_market_regime(df)
        except Exception as exc:
            logger.warning("regime detection failed: %s", exc)
    if action == "buy" and regime in ("RANGE", "CHAOS"):
        action = "hold"
        reason = f"BUY filtered: regime={regime}"
        explanation = _explanation(snap, reason)

    # Filtre de régime — bloquer les BUY en RANGE/CHAOS
    import pandas as pd
    try:
        candles_df = await exchange.fetch_ohlcv_df(snap.symbol if hasattr(snap, 'symbol') else symbol)
        regime = detect_market_regime(candles_df)
    except Exception:
        regime = "UNKNOWN"
    if action == "buy" and regime in ("RANGE", "CHAOS"):
        action = "hold"
        explanation += f" [filtered: regime={regime}]" 

    cached = get_cached_ai(symbol)

    if cached:
        verdict = cached

    elif not use_ai or not _should_call_ai(snap):
        verdict = AIVerdict(
            action=action,
            confidence=abs(snap.score),
            rationale="AI skipped"
        )

    else:
        try:
            verdict = await analyse(snap)
            set_cached_ai(symbol, verdict)
        except Exception as exc:
            logger.warning("AI analyse(%s) failed: %s", symbol, exc)
            verdict = AIVerdict(
                action=action,
                confidence=abs(snap.score),
                rationale=f"AI error: {exc}"
            )

    sig = Signal(
        symbol=symbol,
        timeframe=settings.timeframe,
        price=snap.price,
        action=action,
        score=snap.score,
        rsi=snap.rsi,
        macd=snap.macd,
        macd_signal=snap.macd_signal,
        ma_fast=snap.ma_fast,
        ma_slow=snap.ma_slow,
        ai_action=verdict.action,
        ai_confidence=verdict.confidence,
        ai_rationale=verdict.rationale,
        explanation=explanation,
    )

    session.add(sig)
    await session.flush()

    return SignalResult(
        symbol=symbol,
        snapshot=snap,
        final_action=action,
        explanation=explanation,
        verdict=verdict,
    )


# =====================================
# MULTI SCAN (TOP 1 IA)
# =====================================
async def scan_all(session: AsyncSession, symbols=None):
    syms = symbols or settings.scan_symbols
    raw = await asyncio.gather(*[_compute_snapshot(s) for s in syms])

    valid = [(sym, res[0], res[1]) for sym, res in zip(syms, raw) if res is not None]
    if not valid:
        return []

    results = []
    ai_calls = 0
    for sym, snap, candles in valid:
        use_ai = (ai_calls < settings.max_ai_signals)
        res = await _persist(session, sym, snap, candles, use_ai=use_ai)
        if use_ai:
            ai_calls += 1
        results.append(res)

    await session.commit()
    results.sort(key=lambda r: r.conviction, reverse=True)
    return results
def signal_to_dict(sig):
    return {
        "id": sig.id,
        "ts": sig.ts.isoformat(),
        "symbol": sig.symbol,
        "timeframe": sig.timeframe,
        "price": sig.price,
        "action": sig.action,
        "score": sig.score,
        "rsi": sig.rsi,
        "macd": sig.macd,
        "macd_signal": sig.macd_signal,
        "ma_fast": sig.ma_fast,
        "ma_slow": sig.ma_slow,
        "ai_action": sig.ai_action,
        "ai_confidence": sig.ai_confidence,
        "ai_rationale": sig.ai_rationale,
        "explanation": sig.explanation,
    }


def snapshot_to_dict(snap):
    from dataclasses import asdict
    return asdict(snap)


def trade_to_dict(trade):
    return {
        "id": trade.id,
        "ts": trade.ts.isoformat(),
        "mode": trade.mode,
        "symbol": trade.symbol,
        "side": trade.side,
        "price": trade.price,
        "amount": trade.amount,
        "quote_amount": trade.quote_amount,
        "fee": trade.fee,
        "pnl": trade.pnl,
        "note": trade.note,
    }


def signal_result_to_dict(res):
    snap = res.snapshot
    return {
        "symbol": res.symbol,
        "price": snap.price,
        "action": res.final_action,
        "score": snap.score,
        "conviction": res.conviction,
        "rsi": snap.rsi,
        "macd": snap.macd,
        "macd_signal": snap.macd_signal,
        "ma_fast": snap.ma_fast,
        "ma_slow": snap.ma_slow,
        "bb_upper": snap.bb_upper,
        "bb_lower": snap.bb_lower,
        "explanation": res.explanation,
        "regime": getattr(res, "regime", "UNKNOWN"),
        "ai": {
            "action": res.verdict.action,
            "confidence": res.verdict.confidence,
            "rationale": res.verdict.rationale,
        },
    }

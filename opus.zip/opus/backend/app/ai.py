"""AI confirmation for trading signals (Gemini — exponential backoff + cache)."""
from __future__ import annotations
import asyncio, json, logging, random, time
from dataclasses import dataclass
import httpx
from app.config import settings
from app.indicators import IndicatorSnapshot

logger = logging.getLogger(__name__)

_SYSTEM_PROMPT = (
    "You are a disciplined crypto trading analyst. You receive a snapshot of "
    "technical indicators and must output a single JSON object with exactly "
    "these keys: action (one of buy, sell, hold), confidence (float in [0,1]), "
    "rationale (one short sentence). Be conservative: prefer hold when signals "
    "conflict or confidence is low. Never output anything except the JSON object."
)

_cache: dict[str, tuple[float, "AIVerdict"]] = {}
CACHE_TTL = 240
_last_call_ts: float = 0.0
MIN_DELAY = 2.0

@dataclass
class AIVerdict:
    action: str
    confidence: float
    rationale: str

def _fallback(snap: IndicatorSnapshot, note: str = "") -> AIVerdict:
    return AIVerdict(
        action=snap.action,
        confidence=abs(snap.score),
        rationale=note or "AI disabled; using technical consensus.",
    )

def _parse_verdict(raw: str, snap: IndicatorSnapshot) -> AIVerdict:
    try:
        start, end = raw.find("{"), raw.rfind("}")
        if start != -1 and end != -1:
            raw = raw[start:end+1]
        data = json.loads(raw)
        return AIVerdict(
            action=str(data.get("action", "hold")).lower(),
            confidence=float(data.get("confidence", 0.0)),
            rationale=str(data.get("rationale", "")),
        )
    except Exception:
        return _fallback(snap, "AI parse error.")

async def _post_with_backoff(client, url, params, payload, retries=4):
    global _last_call_ts
    for attempt in range(retries):
        now = time.time()
        wait = _last_call_ts + MIN_DELAY - now
        if wait > 0:
            await asyncio.sleep(wait)
        _last_call_ts = time.time()
        try:
            response = await client.post(url, params=params, json=payload, timeout=20)
            if response.status_code == 200:
                return response.json()
            if response.status_code == 429:
                delay = min(2 ** attempt + random.uniform(0, 1), 60)
                logger.warning("Gemini 429 (attempt %d/%d) — retrying in %.1fs", attempt+1, retries, delay)
                await asyncio.sleep(delay)
                continue
            response.raise_for_status()
        except httpx.TimeoutException:
            logger.warning("Gemini timeout (attempt %d/%d)", attempt+1, retries)
            await asyncio.sleep(2 ** attempt)
        except Exception as exc:
            logger.warning("AI call failed: %s", exc)
            return None
    logger.warning("Gemini gave up after %d attempts", retries)
    return None

async def analyse(snap: IndicatorSnapshot, symbol: str = "") -> AIVerdict:
    if not settings.use_ai_confirmation or not settings.active_ai_provider:
        return _fallback(snap)

    sym = symbol or settings.symbol
    cached = _cache.get(sym)
    if cached and (time.time() - cached[0]) < CACHE_TTL:
        return cached[1]

    prompt = json.dumps({
        "symbol": sym,
        "price": round(snap.price, 2),
        "rsi": round(snap.rsi, 2),
        "technical_action": snap.action,
        "technical_score": round(snap.score, 3),
    })
    payload = {
        "contents": [{"parts": [{"text": f"Snapshot:\n```json\n{prompt}\n```\nRespond with JSON."}]}],
        "system_instruction": {"parts": [{"text": _SYSTEM_PROMPT}]},
        "generationConfig": {"responseMimeType": "application/json"},
    }
    url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-lite:generateContent"

    async with httpx.AsyncClient(trust_env=False) as client:
        result = await _post_with_backoff(client, url, {"key": settings.gemini_api_key}, payload)

    if not result:
        return AIVerdict(action="hold", confidence=0.0, rationale="AI rate limited")

    try:
        raw_text = result["candidates"][0]["content"]["parts"][0]["text"]
        verdict = _parse_verdict(raw_text, snap)
        _cache[sym] = (time.time(), verdict)
        return verdict
    except (KeyError, IndexError):
        return _fallback(snap, "Gemini structure error")

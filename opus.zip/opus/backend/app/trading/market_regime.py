import pandas as pd
import numpy as np

def compute_adx(df, period=14):
    df = df.copy()

    df['H-L'] = df['high'] - df['low']
    df['H-PC'] = abs(df['high'] - df['close'].shift(1))
    df['L-PC'] = abs(df['low'] - df['close'].shift(1))

    df['TR'] = df[['H-L', 'H-PC', 'L-PC']].max(axis=1)

    df['+DM'] = np.where(
        (df['high'] - df['high'].shift(1)) > (df['low'].shift(1) - df['low']),
        np.maximum(df['high'] - df['high'].shift(1), 0),
        0
    )

    df['-DM'] = np.where(
        (df['low'].shift(1) - df['low']) > (df['high'] - df['high'].shift(1)),
        np.maximum(df['low'].shift(1) - df['low'], 0),
        0
    )

    tr_n = df['TR'].rolling(period).sum()
    plus_dm_n = df['+DM'].rolling(period).sum()
    minus_dm_n = df['-DM'].rolling(period).sum()

    plus_di = 100 * (plus_dm_n / tr_n)
    minus_di = 100 * (minus_dm_n / tr_n)

    dx = 100 * (abs(plus_di - minus_di) / (plus_di + minus_di))
    adx = dx.rolling(period).mean()

    return adx.iloc[-1]


def detect_market_regime(df):
    adx = compute_adx(df)

    close = df['close']
    ma50 = close.rolling(50).mean()
    ma200 = close.rolling(200).mean()

    last_price = close.iloc[-1]

    # Trend detection
    if adx > 25:
        if last_price > ma50.iloc[-1] > ma200.iloc[-1]:
            return "TREND_UP"
        elif last_price < ma50.iloc[-1] < ma200.iloc[-1]:
            return "TREND_DOWN"

    # Range
    if adx < 20:
        return "RANGE"

    # Chaos
    return "CHAOS"

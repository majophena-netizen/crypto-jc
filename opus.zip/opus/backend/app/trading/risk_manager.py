def calculate_position_size(balance, risk_per_trade, entry_price, stop_loss_price):
    risk_amount = balance * risk_per_trade
    stop_distance = abs(entry_price - stop_loss_price)

    if stop_distance == 0:
        return 0

    position_size = risk_amount / stop_distance
    return position_size


def apply_risk_management(entry_price, direction):
    if direction == "BUY":
        stop_loss = entry_price * (1 - 0.018)   # -1.8%
        take_profit = entry_price * (1 + 0.025) # +2.5%

    elif direction == "SELL":
        stop_loss = entry_price * (1 + 0.018)
        take_profit = entry_price * (1 - 0.025)

    else:
        return None

    return {
        "stop_loss": stop_loss,
        "take_profit": take_profit
    }

import pandas as pd

def compute_indicators(df):
    df = df.copy()

    df['ma50'] = df['close'].rolling(50).mean()

    delta = df['close'].diff()
    gain = (delta.where(delta > 0, 0)).rolling(14).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(14).mean()

    rs = gain / loss
    df['rsi'] = 100 - (100 / (1 + rs))

    df['ema12'] = df['close'].ewm(span=12).mean()
    df['ema26'] = df['close'].ewm(span=26).mean()
    df['macd'] = df['ema12'] - df['ema26']
    df['signal'] = df['macd'].ewm(span=9).mean()

    return df


def generate_signal(df, regime):
    last = df.iloc[-1]

    rsi = last['rsi']
    macd = last['macd']
    signal = last['signal']
    price = last['close']
    ma50 = last['ma50']

    score = 0

    # Only trade in trend
    if regime == "TREND_UP":
        if 50 < rsi < 65:
            score += 1
        if macd > signal:
            score += 1
        if price > ma50:
            score += 1

        if score >= 3:
            return "BUY", 80

    if regime == "TREND_DOWN":
        if 35 < rsi < 50:
            score += 1
        if macd < signal:
            score += 1
        if price < ma50:
            score += 1

        if score >= 3:
            return "SELL", 80

    return "NO_TRADE", 0

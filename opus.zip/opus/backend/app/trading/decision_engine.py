from app.trading.market_regime import detect_market_regime
from app.trading.signal_engine import compute_indicators, generate_signal
from app.trading.risk_manager import apply_risk_management


def make_decision(df, ai_decision=None):

    df = compute_indicators(df)
    regime = detect_market_regime(df)

    # 🔥 FAILSAFE ABSOLU
    if regime in ["CHAOS", "RANGE"]:
        return {
            "action": "NO_TRADE",
            "reason": f"Blocked by regime ({regime})",
            "regime": regime,
        }

    signal, confidence = generate_signal(df, regime)

    if signal == "NO_TRADE":
        return {
            "action": "NO_TRADE",
            "reason": "Weak signal",
            "regime": regime,
        }

    # IA seulement si valide
    if ai_decision is not None:
        if ai_decision.lower() != signal.lower():
            return {
                "action": "NO_TRADE",
                "reason": "AI disagreement",
                "regime": regime,
            }

    price = df["close"].iloc[-1]
    risk = apply_risk_management(price, signal)

    return {
        "action": signal,
        "confidence": confidence,
        "price": price,
        "regime": regime,
        "stop_loss": risk["stop_loss"],
        "take_profit": risk["take_profit"],
    }

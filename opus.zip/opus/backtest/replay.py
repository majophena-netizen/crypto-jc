"""
Backtest replay du historical signals trader.db sans appel Gemini.
Simule la logique de autotrader.tick_symbol avec differents parametres.
"""
import sqlite3
import sys
from dataclasses import dataclass, field
from itertools import product

DB = '/root/opus/backend/trader.db'
FEE_PCT = 0.1  # Binance taker spot 0.1% per side -> 0.2% round trip

@dataclass
class Position:
    symbol: str
    entry_price: float
    entry_ts: str
    peak_price: float
    consecutive_non_buy: int = 0
    weak_tp_armed: bool = False

@dataclass
class Params:
    take_profit_pct: float = 2.0
    stop_loss_pct: float = 1.5
    trailing_arm_pct: float = 0.5
    trailing_stop_pct: float = 1.0
    weak_take_profit_pct: float = 1.2
    signal_weak_ticks: int = 8
    reversal_conviction_threshold: float = -0.7
    min_hold_minutes: float = 30
    max_hold_hours: float = 12
    min_ai_confidence: float = 0.4
    cooldown_seconds: int = 120

def parse_ts(ts):
    from datetime import datetime
    # strip fractional seconds
    if '.' in ts:
        ts = ts.split('.')[0]
    return datetime.strptime(ts, '%Y-%m-%d %H:%M:%S')

def held_minutes(entry_ts, current_ts):
    return (parse_ts(current_ts) - parse_ts(entry_ts)).total_seconds() / 60.0

def conviction(score, ai_action, ai_confidence):
    ai_sign = 1.0 if ai_action == 'buy' else (-1.0 if ai_action == 'sell' else 0.0)
    ai_w = ai_sign * max(0.0, min(1.0, ai_confidence))
    return abs(0.5 * score + 0.5 * ai_w)

def conviction_signed(score, ai_action, ai_confidence):
    ai_sign = 1.0 if ai_action == 'buy' else (-1.0 if ai_action == 'sell' else 0.0)
    ai_w = ai_sign * max(0.0, min(1.0, ai_confidence))
    return 0.5 * score + 0.5 * ai_w

def backtest(p: Params, signals, max_concurrent=3, verbose=False):
    """Replay signals, return (round_trips, stats)."""
    positions = {}  # symbol -> Position
    last_trade_ts = None
    round_trips = []
    cooldown_seconds = p.cooldown_seconds

    for sig in signals:
        ts, sym, action, price, score, ai_act, ai_conf = sig
        if price <= 0:
            continue

        conv = conviction(score, ai_act, ai_conf)
        conv_signed = conviction_signed(score, ai_act, ai_conf)

        # ---- EXIT logic ----
        if sym in positions:
            pos = positions[sym]
            if price > pos.peak_price:
                pos.peak_price = price
            pnl_pct = (price - pos.entry_price) / pos.entry_price * 100
            peak_pnl_pct = (pos.peak_price - pos.entry_price) / pos.entry_price * 100
            held = held_minutes(pos.entry_ts, ts)

            exit_reason = None

            # 1. TP
            if pnl_pct >= p.take_profit_pct:
                exit_reason = 'exit_tp'
            # 2. SL
            elif pnl_pct <= -p.stop_loss_pct:
                exit_reason = 'exit_sl'
            # 3. Trailing
            elif peak_pnl_pct >= p.trailing_arm_pct and pos.peak_price > 0:
                drawdown = (pos.peak_price - price) / pos.peak_price * 100.0
                if drawdown >= p.trailing_stop_pct:
                    exit_reason = 'exit_trail'

            if exit_reason is None and held >= p.min_hold_minutes:
                # 4. Sell signal
                if action == 'sell':
                    exit_reason = 'exit_signal'
                # 4b. Strong reversal
                elif conv_signed <= p.reversal_conviction_threshold:
                    exit_reason = 'exit_reversal'
                else:
                    # 5. weak counter
                    if action != 'buy':
                        pos.consecutive_non_buy += 1
                    else:
                        pos.consecutive_non_buy = 0
                    # 5a. weak TP
                    if (pos.consecutive_non_buy >= 1
                            and pnl_pct >= p.weak_take_profit_pct > 0):
                        exit_reason = 'exit_weak_tp'
                    # 5b. forced weak
                    elif (p.signal_weak_ticks > 0
                            and pos.consecutive_non_buy >= p.signal_weak_ticks):
                        exit_reason = 'exit_weak'

            # 6. Timeout
            if exit_reason is None and held / 60.0 >= p.max_hold_hours > 0:
                exit_reason = 'exit_timeout'

            if exit_reason:
                # Net PnL = brut - fees (entry + exit)
                gross_pct = pnl_pct
                net_pct = gross_pct - 2 * FEE_PCT
                round_trips.append({
                    'symbol': sym,
                    'entry_ts': pos.entry_ts,
                    'exit_ts': ts,
                    'entry': pos.entry_price,
                    'exit': price,
                    'held_min': held,
                    'gross_pct': gross_pct,
                    'net_pct': net_pct,
                    'reason': exit_reason,
                })
                last_trade_ts = ts
                del positions[sym]
                continue

        # ---- ENTRY logic ----
        if sym not in positions and action == 'buy':
            if len(positions) >= max_concurrent:
                continue
            if last_trade_ts:
                gap = (parse_ts(ts) - parse_ts(last_trade_ts)).total_seconds()
                if gap < cooldown_seconds:
                    continue
            if ai_conf < p.min_ai_confidence:
                continue
            positions[sym] = Position(
                symbol=sym, entry_price=price, entry_ts=ts, peak_price=price,
            )
            last_trade_ts = ts

    # close open positions at last known price
    return round_trips

def stats(round_trips):
    if not round_trips:
        return {'n':0, 'pnl':0, 'wr':0, 'avg':0, 'min':0, 'max':0, 'reasons':{}}
    pnls = [r['net_pct'] for r in round_trips]
    wins = sum(1 for p in pnls if p > 0)
    reasons = {}
    for r in round_trips:
        reasons[r['reason']] = reasons.get(r['reason'], 0) + 1
    return {
        'n': len(round_trips),
        'pnl': sum(pnls),
        'wr': wins * 100 / len(pnls),
        'avg': sum(pnls) / len(pnls),
        'min': min(pnls),
        'max': max(pnls),
        'reasons': reasons,
    }

def main():
    con = sqlite3.connect(DB)
    cur = con.cursor()
    rows = list(cur.execute("SELECT ts,symbol,action,price,score,ai_action,ai_confidence FROM signals ORDER BY ts ASC"))
    print(f'Loaded {len(rows)} signals from DB.')

    print('\n=== BASELINE (current config) ===')
    base = Params()
    rts = backtest(base, rows)
    s = stats(rts)
    print(f'  n={s["n"]}  net_pnl_pct={s["pnl"]:+.2f}%  WR={s["wr"]:.0f}%  avg={s["avg"]:+.2f}%/trade  min={s["min"]:+.2f}%  max={s["max"]:+.2f}%')
    print(f'  exit reasons: {s["reasons"]}')

    # Test current observed config (signal_weak_ticks=3 from logs)
    print('\n=== OBSERVED LIVE (signal_weak_ticks=3, what actually happened) ===')
    p = Params(signal_weak_ticks=3)
    rts = backtest(p, rows)
    s = stats(rts)
    print(f'  n={s["n"]}  net_pnl_pct={s["pnl"]:+.2f}%  WR={s["wr"]:.0f}%  avg={s["avg"]:+.2f}%/trade')
    print(f'  exit reasons: {s["reasons"]}')

    print('\n=== GRID SEARCH (focal exit params) ===')
    candidates = []
    for swt, mhm, wtp, tpp, slp in product(
        [3, 5, 8, 12, 15, 20, 30],   # signal_weak_ticks
        [15, 30, 60, 90],             # min_hold_minutes
        [0.4, 0.6, 0.8, 1.0, 1.2],   # weak_take_profit_pct
        [1.5, 2.0, 2.5],              # take_profit_pct
        [0.8, 1.0, 1.5, 2.0],         # stop_loss_pct
    ):
        p = Params(
            signal_weak_ticks=swt, min_hold_minutes=mhm,
            weak_take_profit_pct=wtp, take_profit_pct=tpp, stop_loss_pct=slp,
        )
        rts = backtest(p, rows)
        s = stats(rts)
        if s['n'] < 5: continue
        candidates.append((s['pnl'], s, p))

    candidates.sort(key=lambda x: -x[0])
    print(f'  Tested {len(candidates)} valid combos.')
    print(f'\n  TOP 10 by net PnL:')
    print(f'  {"swt":>4} {"mhm":>4} {"wtp":>5} {"tp":>5} {"sl":>5} | {"n":>4} {"WR":>4} {"PnL":>7} {"avg":>7}')
    for pnl, s, p in candidates[:10]:
        print(f'  {p.signal_weak_ticks:>4} {p.min_hold_minutes:>4.0f} {p.weak_take_profit_pct:>5.1f} {p.take_profit_pct:>5.1f} {p.stop_loss_pct:>5.1f} | {s["n"]:>4} {s["wr"]:>3.0f}% {s["pnl"]:>+6.2f}% {s["avg"]:>+6.2f}%')

    print(f'\n  WORST 5 by net PnL:')
    for pnl, s, p in candidates[-5:]:
        print(f'  {p.signal_weak_ticks:>4} {p.min_hold_minutes:>4.0f} {p.weak_take_profit_pct:>5.1f} {p.take_profit_pct:>5.1f} {p.stop_loss_pct:>5.1f} | {s["n"]:>4} {s["wr"]:>3.0f}% {s["pnl"]:>+6.2f}% {s["avg"]:>+6.2f}%')

if __name__ == '__main__':
    main()

"""Final tests: high-score entries, per-symbol perf, fee sensitivity."""
import sqlite3
import sys
sys.path.insert(0, '/root/opus/backtest')
import replay
from replay import Params, backtest, stats

DB = '/root/opus/backend/trader.db'
con = sqlite3.connect(DB)
cur = con.cursor()
rows = list(cur.execute("SELECT ts,symbol,action,price,score,ai_action,ai_confidence FROM signals ORDER BY ts ASC"))

print('=== TEST 3: only highest-score entries (filter by score) ===')
# Filter input signals: keep buy only if score >= threshold
for thr in [0.6, 0.7, 0.8, 0.9, 1.0]:
    filtered = []
    for r in rows:
        ts,sym,action,price,score,ai_act,ai_conf = r
        if action == 'buy' and score < thr:
            filtered.append((ts,sym,'hold',price,score,ai_act,ai_conf))
        else:
            filtered.append(r)
    p = Params(signal_weak_ticks=999, min_hold_minutes=0,
               take_profit_pct=1.0, stop_loss_pct=1.0,
               trailing_arm_pct=0.5, trailing_stop_pct=0.5)
    rts = backtest(p, filtered)
    s = stats(rts)
    print(f'  score_thr={thr} | n={s["n"]} WR={s["wr"]:.0f}% PnL={s["pnl"]:+.2f}% avg={s["avg"]:+.2f}%/trade | {s["reasons"]}')

print()
print('=== TEST 4: per-symbol performance (baseline params, swt=8) ===')
for sym in sorted(set(r[1] for r in rows)):
    sym_rows = [r for r in rows if r[1] == sym]
    p = Params()
    rts = backtest(p, sym_rows)
    s = stats(rts)
    if s['n'] == 0:
        print(f'  {sym}: no trades')
        continue
    print(f'  {sym}: n={s["n"]} WR={s["wr"]:.0f}% PnL={s["pnl"]:+.2f}% avg={s["avg"]:+.2f}%')

print()
print('=== TEST 5: fee sensitivity (lower fees = better edge?) ===')
# Lower fees would simulate VIP tier. Let's see if 0.05% fees per side make a difference.
for fee in [0.10, 0.075, 0.05, 0.025, 0.0]:
    replay.FEE_PCT = fee
    p = Params()
    rts = backtest(p, rows)
    s = stats(rts)
    print(f'  fee_per_side={fee}% (round={2*fee}%) | n={s["n"]} WR={s["wr"]:.0f}% PnL={s["pnl"]:+.2f}% avg={s["avg"]:+.2f}%')

print()
print('=== TEST 6: high score + high TP, allow long holds ===')
replay.FEE_PCT = 0.10  # back to spot fees
for thr in [0.7, 0.8, 0.9]:
    filtered = []
    for r in rows:
        ts,sym,action,price,score,ai_act,ai_conf = r
        if action == 'buy' and score < thr:
            filtered.append((ts,sym,'hold',price,score,ai_act,ai_conf))
        else:
            filtered.append(r)
    for tpp, slp, max_hr in [(2.0, 1.0, 24), (3.0, 1.5, 48), (1.5, 0.8, 12)]:
        p = Params(signal_weak_ticks=999, min_hold_minutes=0,
                   take_profit_pct=tpp, stop_loss_pct=slp, max_hold_hours=max_hr)
        rts = backtest(p, filtered)
        s = stats(rts)
        if s['n'] < 2: continue
        print(f'  score>={thr} TP={tpp} SL={slp} max_hr={max_hr} | n={s["n"]} WR={s["wr"]:.0f}% PnL={s["pnl"]:+.2f}% avg={s["avg"]:+.2f}%')

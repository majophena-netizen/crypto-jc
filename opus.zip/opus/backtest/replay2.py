"""Backtest deeper: test entry filtering + per-symbol + disable weak exit."""
import sqlite3
from itertools import product
import sys
sys.path.insert(0, '/root/opus/backtest')
from replay import Params, backtest, stats, parse_ts, conviction

DB = '/root/opus/backend/trader.db'
con = sqlite3.connect(DB)
cur = con.cursor()
rows = list(cur.execute("SELECT ts,symbol,action,price,score,ai_action,ai_confidence FROM signals ORDER BY ts ASC"))
print(f'Loaded {len(rows)} signals')
print()

print('=== TEST 1: Disable weak exit (rely on TP/SL/trail/timeout) ===')
for swt in [999]:
    for mhm in [0]:
        for tpp, slp, trl_arm, trl_stop in product([1.0, 1.5, 2.0], [0.5, 1.0, 1.5], [0.3, 0.5, 0.8], [0.3, 0.5, 0.8]):
            p = Params(signal_weak_ticks=swt, min_hold_minutes=mhm,
                       take_profit_pct=tpp, stop_loss_pct=slp,
                       trailing_arm_pct=trl_arm, trailing_stop_pct=trl_stop)
            rts = backtest(p, rows)
            s = stats(rts)
            if s['n'] < 5: continue
            print(f'  TP={tpp} SL={slp} trail_arm={trl_arm} trail_stop={trl_stop} | n={s["n"]} WR={s["wr"]:.0f}% PnL={s["pnl"]:+.2f}% avg={s["avg"]:+.2f}% | reasons={s["reasons"]}')

print()
print('=== TEST 2: Higher min_ai_confidence filter (stronger entries only) ===')
for ai_min in [0.4, 0.5, 0.55, 0.6, 0.7, 0.8]:
    for tpp in [1.0, 1.5, 2.0]:
        for slp in [0.8, 1.0, 1.5]:
            p = Params(min_ai_confidence=ai_min, signal_weak_ticks=999, min_hold_minutes=0,
                       take_profit_pct=tpp, stop_loss_pct=slp)
            rts = backtest(p, rows)
            s = stats(rts)
            if s['n'] < 3: continue
            print(f'  AI_conf>={ai_min} TP={tpp} SL={slp} | n={s["n"]} WR={s["wr"]:.0f}% PnL={s["pnl"]:+.2f}% avg={s["avg"]:+.2f}%')
